import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../../store/authStore';
import { useSettingsStore } from '../../store/settingsStore';
import { User, Lock, Upload, AlertTriangle, Phone, Globe, Building, Mail, MapPin, Eye, EyeOff, Sun, Moon, Palette, Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Settings() {
  const { user, studentData, checkAuth, logout } = useAuthStore();
  const { theme, setTheme, toggleTheme } = useSettingsStore();
  const navigate = useNavigate();
  
  const [activeTab, setActiveTab] = useState<'profile' | 'appearance' | 'password' | 'danger'>('profile');
  
  // Profile Editable states
  const [phone, setPhone] = useState(user?.phone || '');
  const [country, setCountry] = useState(user?.country || '');
  const [state, setState] = useState(user?.state || '');
  const [secondaryEmail, setSecondaryEmail] = useState(user?.secondaryEmail || '');
  
  // Student data editable states
  const [institution, setInstitution] = useState(studentData?.institution || '');
  const [department, setDepartment] = useState(studentData?.department || '');
  const [level, setLevel] = useState(studentData?.level || '');
  const [photo, setPhoto] = useState<File | null>(null);
  
  // Password states
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  
  const [isUpdating, setIsUpdating] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  useEffect(() => {
    if (user) {
      setPhone(user.phone || '');
      setCountry(user.country || '');
      setState(user.state || '');
      setSecondaryEmail(user.secondaryEmail || '');
    }
    if (studentData) {
      setInstitution(studentData.institution || '');
      setDepartment(studentData.department || '');
      setLevel(studentData.level || '');
    }
  }, [user, studentData]);

  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdating(true);
    setMessage({ type: '', text: '' });

    try {
      const formData = new FormData();
      formData.append('phone', phone);
      formData.append('country', country);
      formData.append('state', state);
      formData.append('secondaryEmail', secondaryEmail);
      formData.append('institution', institution);
      formData.append('department', department);
      formData.append('level', level);
      
      if (photo) {
        formData.append('profilePhoto', photo);
      }

      const response = await fetch('/api/users/profile', {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: formData
      });

      if (!response.ok) throw new Error('Failed to update profile');
      
      setMessage({ type: 'success', text: 'All profile changes saved successfully!' });
      await checkAuth(); // Refresh user data
    } catch (err) {
      setMessage({ type: 'error', text: 'An error occurred while updating profile.' });
    } finally {
      setIsUpdating(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdating(true);
    setMessage({ type: '', text: '' });

    try {
      const response = await fetch('/api/users/password', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ currentPassword, newPassword })
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to change password');
      
      setMessage({ type: 'success', text: 'Password changed successfully!' });
      setCurrentPassword('');
      setNewPassword('');
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!window.confirm("Are you absolutely sure you want to delete your account? This action cannot be undone and you will lose all access, coins, and progress.")) {
      return;
    }

    try {
      const response = await fetch('/api/users/profile', {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });

      if (!response.ok) throw new Error('Failed to delete account');
      
      logout();
      navigate('/');
    } catch (err) {
      setMessage({ type: 'error', text: 'Could not delete account. Please try again or contact support.' });
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm overflow-hidden transition-colors">
        <div className="flex border-b border-zinc-200 dark:border-zinc-800 overflow-x-auto hide-scrollbar">
          <button 
            onClick={() => { setActiveTab('profile'); setMessage({ type: '', text: '' }); }}
            className={`px-6 py-4 text-sm font-bold whitespace-nowrap transition-colors cursor-pointer ${activeTab === 'profile' ? 'border-b-2 border-zinc-900 dark:border-white text-zinc-900 dark:text-white' : 'text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'}`}
          >
            Edit Profile
          </button>
          <button 
            onClick={() => { setActiveTab('appearance'); setMessage({ type: '', text: '' }); }}
            className={`px-6 py-4 text-sm font-bold whitespace-nowrap transition-colors cursor-pointer ${activeTab === 'appearance' ? 'border-b-2 border-zinc-900 dark:border-white text-zinc-900 dark:text-white' : 'text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'}`}
          >
            Appearance & Theme
          </button>
          <button 
            onClick={() => { setActiveTab('password'); setMessage({ type: '', text: '' }); }}
            className={`px-6 py-4 text-sm font-bold whitespace-nowrap transition-colors cursor-pointer ${activeTab === 'password' ? 'border-b-2 border-zinc-900 dark:border-white text-zinc-900 dark:text-white' : 'text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'}`}
          >
            Change Password
          </button>
          <button 
            onClick={() => { setActiveTab('danger'); setMessage({ type: '', text: '' }); }}
            className={`px-6 py-4 text-sm font-bold whitespace-nowrap transition-colors cursor-pointer ${activeTab === 'danger' ? 'border-b-2 border-red-600 text-red-600' : 'text-zinc-500 hover:text-red-600'}`}
          >
            Danger Zone
          </button>
        </div>

        <div className="p-6 sm:p-8">
          {message.text && (
            <div className={`mb-6 p-4 rounded-xl text-sm font-semibold ${message.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800' : 'bg-red-50 text-red-800 border border-red-200 dark:bg-red-950/40 dark:text-red-300 dark:border-red-800'}`}>
              {message.text}
            </div>
          )}

          {activeTab === 'appearance' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-100">Display Theme Preference</h3>
                <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
                  Choose how Medcore Academy looks to you. Your theme selection is automatically saved in your settings store and synced across all pages.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                {/* Light Mode Card */}
                <div 
                  onClick={() => setTheme('light')}
                  className={`relative p-5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                    theme === 'light' 
                      ? 'border-red-600 bg-red-50/40 dark:bg-zinc-800 shadow-md ring-2 ring-red-500/20' 
                      : 'border-zinc-200 dark:border-zinc-700 hover:border-zinc-300 dark:hover:border-zinc-600 bg-white dark:bg-zinc-800/40'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="p-2.5 rounded-xl bg-amber-100 text-amber-600 dark:bg-amber-900/50 dark:text-amber-400">
                        <Sun className="h-6 w-6" />
                      </div>
                      {theme === 'light' && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-red-600 text-white">
                          <Check className="h-3 w-3 mr-1" /> Active
                        </span>
                      )}
                    </div>
                    <h4 className="text-base font-bold text-zinc-900 dark:text-zinc-100">Light Mode</h4>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
                      Crisp, high-contrast white background with clean medical typography. Optimal for daytime study.
                    </p>
                  </div>

                  <div className="mt-4 pt-4 border-t border-zinc-100 dark:border-zinc-700/60 flex items-center justify-between text-xs font-semibold text-zinc-600 dark:text-zinc-300">
                    <span>Preview</span>
                    <span className="px-2 py-1 bg-white border border-zinc-200 rounded-md text-zinc-800 font-mono text-[10px]">
                      Aa Bb 123
                    </span>
                  </div>
                </div>

                {/* Dark Mode Card */}
                <div 
                  onClick={() => setTheme('dark')}
                  className={`relative p-5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                    theme === 'dark' 
                      ? 'border-red-600 bg-zinc-900 text-white shadow-md ring-2 ring-red-500/20' 
                      : 'border-zinc-200 dark:border-zinc-700 hover:border-zinc-300 dark:hover:border-zinc-600 bg-white dark:bg-zinc-800/40'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="p-2.5 rounded-xl bg-zinc-800 text-sky-400 border border-zinc-700">
                        <Moon className="h-6 w-6" />
                      </div>
                      {theme === 'dark' && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-red-600 text-white">
                          <Check className="h-3 w-3 mr-1" /> Active
                        </span>
                      )}
                    </div>
                    <h4 className="text-base font-bold text-zinc-900 dark:text-zinc-100">Dark Mode</h4>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
                      Deep slate & obsidian background engineered to minimize eye strain during late-night clinical study.
                    </p>
                  </div>

                  <div className="mt-4 pt-4 border-t border-zinc-100 dark:border-zinc-700/60 flex items-center justify-between text-xs font-semibold text-zinc-600 dark:text-zinc-300">
                    <span>Preview</span>
                    <span className="px-2 py-1 bg-zinc-950 border border-zinc-800 rounded-md text-zinc-100 font-mono text-[10px]">
                      Aa Bb 123
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
                <span className="text-sm font-medium text-zinc-700 dark:text-zinc-300">Quick Toggle</span>
                <button
                  type="button"
                  onClick={toggleTheme}
                  className="px-4 py-2 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 text-xs font-bold rounded-xl transition-colors inline-flex items-center space-x-2 cursor-pointer"
                >
                  {theme === 'dark' ? (
                    <>
                      <Sun className="h-4 w-4 text-amber-500" />
                      <span>Switch to Light Mode</span>
                    </>
                  ) : (
                    <>
                      <Moon className="h-4 w-4 text-zinc-600" />
                      <span>Switch to Dark Mode</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {activeTab === 'profile' && (
            <form onSubmit={handleProfileUpdate} className="space-y-6">
              {/* Photo Upload Row */}
              <div>
                <label className="block text-xs font-black text-zinc-400 uppercase tracking-wider mb-2">Profile Photo</label>
                <div className="flex items-center space-x-6">
                  <div className="h-20 w-20 rounded-full bg-zinc-100 border border-zinc-200 flex items-center justify-center overflow-hidden shrink-0">
                    {photo ? (
                      <img src={URL.createObjectURL(photo)} alt="Preview" className="h-full w-full object-cover" />
                    ) : user?.profilePhoto ? (
                      <img src={user.profilePhoto} alt="Current" className="h-full w-full object-cover" />
                    ) : (
                      <User className="h-8 w-8 text-zinc-400" />
                    )}
                  </div>
                  <div>
                    <label className="cursor-pointer inline-flex items-center px-3.5 py-2 border border-zinc-200 shadow-xs text-xs font-bold uppercase tracking-wider rounded-xl text-zinc-700 bg-white hover:bg-zinc-50 transition-colors">
                      <Upload className="h-4 w-4 mr-2 text-zinc-500" />
                      Select Photo
                      <input type="file" className="hidden" accept="image/*" onChange={(e) => setPhoto(e.target.files?.[0] || null)} />
                    </label>
                    <p className="mt-1 text-[10px] text-zinc-500">JPG or PNG. Maximum size 5MB.</p>
                  </div>
                </div>
              </div>

              {/* Read-Only Locked Fields */}
              <div className="pt-4 border-t border-zinc-100 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black text-zinc-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                    Full Name <Lock className="h-3 w-3 text-zinc-400" />
                  </label>
                  <input
                    type="text"
                    disabled
                    value={user?.name || ''}
                    className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm text-zinc-500 cursor-not-allowed font-medium"
                    title="This field is locked and can only be updated by administration."
                  />
                  <span className="text-[10px] text-zinc-400 mt-0.5 block">Locked: Contact support to change.</span>
                </div>

                <div>
                  <label className="block text-xs font-black text-zinc-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                    Email Address <Lock className="h-3 w-3 text-zinc-400" />
                  </label>
                  <input
                    type="email"
                    disabled
                    value={user?.email || ''}
                    className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm text-zinc-500 cursor-not-allowed font-medium"
                    title="This field is locked and can only be updated by administration."
                  />
                  <span className="text-[10px] text-zinc-400 mt-0.5 block">Locked: Contact support to change.</span>
                </div>
              </div>

              {/* Editable Fields Grid */}
              <div className="pt-4 border-t border-zinc-100 grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Secondary Email */}
                <div>
                  <label className="block text-xs font-black text-zinc-700 uppercase tracking-wider mb-1.5">Secondary Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-3 h-4 w-4 text-zinc-400" />
                    <input
                      type="email"
                      value={secondaryEmail}
                      onChange={(e) => setSecondaryEmail(e.target.value)}
                      placeholder="e.g. secondary@mail.com"
                      className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-sm focus:bg-white focus:border-zinc-900 outline-none transition-all text-zinc-800"
                    />
                  </div>
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-xs font-black text-zinc-700 uppercase tracking-wider mb-1.5">Phone Number</label>
                  <div className="relative">
                    <Phone className="absolute left-3.5 top-3 h-4 w-4 text-zinc-400" />
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="e.g. +234 800 000 0000"
                      className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-sm focus:bg-white focus:border-zinc-900 outline-none transition-all text-zinc-800"
                    />
                  </div>
                </div>

                {/* Country */}
                <div>
                  <label className="block text-xs font-black text-zinc-700 uppercase tracking-wider mb-1.5">Country</label>
                  <div className="relative">
                    <Globe className="absolute left-3.5 top-3 h-4 w-4 text-zinc-400" />
                    <input
                      type="text"
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      placeholder="e.g. Nigeria"
                      className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-sm focus:bg-white focus:border-zinc-900 outline-none transition-all text-zinc-800"
                    />
                  </div>
                </div>

                {/* State */}
                <div>
                  <label className="block text-xs font-black text-zinc-700 uppercase tracking-wider mb-1.5">State / Region</label>
                  <div className="relative">
                    <MapPin className="absolute left-3.5 top-3 h-4 w-4 text-zinc-400" />
                    <input
                      type="text"
                      value={state}
                      onChange={(e) => setState(e.target.value)}
                      placeholder="e.g. Lagos"
                      className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-sm focus:bg-white focus:border-zinc-900 outline-none transition-all text-zinc-800"
                    />
                  </div>
                </div>
              </div>

              {/* Student Academic Details Section */}
              <div className="pt-4 border-t border-zinc-100 grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Institution */}
                <div className="md:col-span-1">
                  <label className="block text-xs font-black text-zinc-700 uppercase tracking-wider mb-1.5">Institution / University</label>
                  <div className="relative">
                    <Building className="absolute left-3.5 top-3 h-4 w-4 text-zinc-400" />
                    <input
                      type="text"
                      value={institution}
                      onChange={(e) => setInstitution(e.target.value)}
                      placeholder="e.g. UNILAG"
                      className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-sm focus:bg-white focus:border-zinc-900 outline-none transition-all text-zinc-800"
                    />
                  </div>
                </div>

                {/* Department */}
                <div>
                  <label className="block text-xs font-black text-zinc-700 uppercase tracking-wider mb-1.5">Department / Faculty</label>
                  <input
                    type="text"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    placeholder="e.g. Medicine & Surgery"
                    className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-sm focus:bg-white focus:border-zinc-900 outline-none transition-all text-zinc-800"
                  />
                </div>

                {/* Academic Level */}
                <div>
                  <label className="block text-xs font-black text-zinc-700 uppercase tracking-wider mb-1.5">Academic Level</label>
                  <input
                    type="text"
                    value={level}
                    onChange={(e) => setLevel(e.target.value)}
                    placeholder="e.g. 400 Level"
                    className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-sm focus:bg-white focus:border-zinc-900 outline-none transition-all text-zinc-800"
                  />
                </div>
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  disabled={isUpdating}
                  className="w-full flex justify-center py-2.5 px-4 bg-zinc-900 hover:bg-zinc-800 active:scale-[0.99] text-white text-xs font-black uppercase tracking-wider rounded-xl shadow-xs disabled:opacity-50 transition-all cursor-pointer"
                >
                  {isUpdating ? 'Saving...' : 'Save Profile Changes'}
                </button>
              </div>
            </form>
          )}

          {activeTab === 'password' && (
            <form onSubmit={handlePasswordChange} className="space-y-6">
              <div>
                <label className="block text-xs font-black text-zinc-700 uppercase tracking-wider mb-1.5">Current Password</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Lock className="h-4 w-4 text-zinc-400" />
                  </div>
                  <input
                    type={showCurrentPassword ? 'text' : 'password'}
                    required
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="block w-full pl-10 pr-10 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-sm focus:bg-white focus:border-zinc-900 outline-none transition-all text-zinc-800"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-zinc-400 hover:text-zinc-600 focus:outline-none cursor-pointer"
                    aria-label={showCurrentPassword ? 'Hide password' : 'Show password'}
                    tabIndex={-1}
                  >
                    {showCurrentPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-zinc-700 uppercase tracking-wider mb-1.5">New Password</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Lock className="h-4 w-4 text-zinc-400" />
                  </div>
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="block w-full pl-10 pr-10 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-sm focus:bg-white focus:border-zinc-900 outline-none transition-all text-zinc-800"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-zinc-400 hover:text-zinc-600 focus:outline-none cursor-pointer"
                    aria-label={showNewPassword ? 'Hide password' : 'Show password'}
                    tabIndex={-1}
                  >
                    {showNewPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  disabled={isUpdating}
                  className="w-full flex justify-center py-2.5 px-4 bg-zinc-900 hover:bg-zinc-800 active:scale-[0.99] text-white text-xs font-black uppercase tracking-wider rounded-xl shadow-xs disabled:opacity-50 transition-all cursor-pointer"
                >
                  {isUpdating ? 'Updating...' : 'Update Password'}
                </button>
              </div>
            </form>
          )}

          {activeTab === 'danger' && (
            <div className="space-y-6">
              <div className="bg-red-50 border border-red-200 rounded-xl p-5 flex items-start">
                <AlertTriangle className="h-6 w-6 text-red-600 mt-0.5 mr-3 flex-shrink-0" />
                <div>
                  <h4 className="text-base font-bold text-red-900">Delete Account</h4>
                  <p className="text-sm text-red-800 mt-1 mb-4">
                    Once you delete your account, there is no going back. All of your quiz history, course progress, and Medcore Coins will be permanently deleted.
                  </p>
                  <button
                    onClick={handleDeleteAccount}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-xs font-black uppercase tracking-wider rounded-xl text-white bg-red-600 hover:bg-red-700 cursor-pointer transition-colors"
                  >
                    Delete My Account
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
